from stem.descriptor.server_descriptor import RelayDescriptor

print(RelayDescriptor.content({'router': 'demo 127.0.0.1 80 0 0'}))
