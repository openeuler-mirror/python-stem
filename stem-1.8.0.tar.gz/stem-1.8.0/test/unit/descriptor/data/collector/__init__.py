"""
Test data for test.unit.descriptor's collector tests.
"""

__all__ = [
  'index',
]
